// --- (Pega esto al final de js/views/ui-helpers.js) ---

// --- MODAL DE DETALLES DEL DÍA ---

export function openDayDetails(dateStr) {
    const modal = document.getElementById('day-details-modal');
    const title = document.getElementById('day-details-title');
    const body = document.getElementById('day-details-body');
    const btnAdd = document.getElementById('btn-add-task-on-day');

    const dateObj = new Date(dateStr + 'T00:00:00');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    title.textContent = dateObj.toLocaleDateString('es-ES', options);
    body.innerHTML = '';

    // Filtrar tareas para este día específico
    let dayTasks = state.tasks.filter(t => {
        if (!isTaskOnDate(t, dateObj)) return false;
        // Excluir comentarios y notas
        if (t.isTimelineComment || (t.category && (t.category.includes('|||comment') || t.category.includes('|||note')))) return false;
        return true;
    });

    // Aplicar Filtro de Carpeta (si está activo en el sidebar)
    if (state.activeFilters.folderId) {
        dayTasks = dayTasks.filter(t => t.parentId === state.activeFilters.folderId);
    }

    // Aplicar Filtro de Tags Principales
    if (state.activeFilters.mainTags && state.activeFilters.mainTags.size > 0) {
        dayTasks = dayTasks.filter(t => {
            if (!t.category) return false;
            const taskTags = t.category.split(',').map(tag => tag.trim());
            return [...state.activeFilters.mainTags].every(tag => taskTags.includes(tag));
        });
    }

    if (dayTasks.length === 0) {
        body.innerHTML = '<p style="text-align:center; color:var(--text-secondary); margin-top:20px;">No hay tareas para este día.</p>';
    } else {
        dayTasks.forEach(task => {
            const item = document.createElement('div');
            item.className = 'task-item';
            // Usamos false para hasSubtasks e isSubtask porque en esta vista simplificada no expandimos
            const taskEl = createTaskElement(task, false, false);

            // Ocultar toggle de subtareas en esta vista
            const toggle = taskEl.querySelector('.btn-toggle-subtasks');
            if (toggle) toggle.style.visibility = 'hidden';

            item.appendChild(taskEl);
            body.appendChild(taskEl);
        });
    }

    // Configurar botón "Añadir tarea aquí"
    btnAdd.onclick = () => {
        closeDayDetails();
        openModal(); // Función interna de ui-helpers
        document.getElementById('task-date').value = dateStr;
    };

    modal.classList.add('active');

    // Fix de estilos (Legacy support)
    modal.style.setProperty('display', 'flex', 'important');
    modal.style.setProperty('opacity', '1', 'important');
    modal.style.setProperty('pointer-events', 'none', 'important');

    setTimeout(() => {
        modal.style.setProperty('pointer-events', 'all', 'important');
    }, 100);
}

export function closeDayDetails() {
    const modal = document.getElementById('day-details-modal');
    modal.classList.remove('active');
    modal.style.display = '';
    modal.style.opacity = '';
    modal.style.pointerEvents = '';
}